import view.LoginGUI;

public class Main {
    public static void main(String[] args) {
        new LoginGUI(); // Inicializa o sistema pela tela de login
    }
}
